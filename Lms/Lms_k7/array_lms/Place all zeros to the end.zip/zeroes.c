#include<stdio.h>
int main()
{
    int n,a[99],i,j=1,temp,count=0;
    printf("Enter the n value:");
    scanf("%d",&n);
    printf("Enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
        
    }
    if(n<=0)
    {
        printf("invalid size");
        
    }
    if(n>100)
    {
        printf("Memory overflow");
    }
    else
    {
        for(i=0;i<n;i++)
        {
            if(a[i]==0)
            {
                count++;
            }
        }
        while(j<=count)
        {
            for(i=0;i<n;i++)
            {
                if(a[i]==0)
                {
                    temp=a[i];
                    a[i]=a[i+1];
                    a[i+1]=temp;
                }
            }
            j++;
        }
       for(i=0;i<n;i++)
      {
        printf("%d ",a[i]);
      }
}
}