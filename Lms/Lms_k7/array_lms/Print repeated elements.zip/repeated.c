#include<stdio.h>
void repeated(int *,int);
int main()
{
    int a[20],n,i;
    printf("Enter the n value:");
    scanf("%d",&n);
    printf("Enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    if(n<=0)
    {
        printf("invalid size");
    }
    else
    {
      repeated(a,n);
    }
}

void repeated(int *p,int num)
{
    int i,j,count,f,k;
    for(i=0;i<num;i++)
    {
        count=0;
        f=0;
        for(j=i-1;j>=0;j--)
        {
            if(p[i]==p[j])
            {
            f=1;
            break;
            }
        }
        if(f==0)
        {
            for(k=i+1;k<num;k++)
            {
                if(p[k]==p[i])
                count++;
            }

               if(count>0)
               {
                printf("%d ",p[i]);
               }
            }
            if(count==0)
            printf("no repeated elements");
        }
}