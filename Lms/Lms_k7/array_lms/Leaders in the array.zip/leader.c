#include<stdio.h>
void check_leader(int *,int);
int main()
{
    int i,n,a[10];
    printf("Enter the n value:");
    scanf("%d",&n);
    if(n>0)
    {
        printf("Enter the elements:");
        for(i=0;i<n;i++)
        {
          scanf("%d",&a[i]);
        }
        check_leader(a,n);
    }
    else
    {
        printf("Invalid size");
    }
}

void check_leader(int *p,int num)
{
    int i,j,count=0;
    for(i=0;i<num;i++)
    {
        count=0;
        for(j=i+1;j<num;j++)
        {
            if(p[i]>=p[j])
            {
                count++;
            }
        }
        if(count==num-(i+1))
        {
            printf("%d ",p[i]);
    
        }
    }
}