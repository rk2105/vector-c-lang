#include<stdio.h>
int main()
{
    char choice,r,l;
    int temp,j=1,k=1,i,ri,le,n,a[20];
    scanf("%d",&n);
    if(n<=0)
    {
        printf("No of elements are invalid");
    }
    else
    {
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
        
    }
    scanf(" %c",&choice);
    if(choice=='r')
    {
    
    
        scanf("%d",&ri);
        while(j<=ri)
        {
            temp=a[n-1];
          for(i=n-1;i>0;i--)
         {
               a[i]=a[i-1];
         }
         a[i]=temp;
         j++;
    }
    for(i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
    }
    if(choice=='l')
    {
        printf("Enter the l value:");
        scanf("%d",&le);
        while(k<=le)
        {
            temp=a[0];
            for(i=0;i<n-1;i++)
            {
                a[i]=a[i+1];
            }
            a[i]=temp;
            k++;
        }
        for(i=0;i<n;i++)
        {
            printf("%d ",a[i]);
        }
    }
    }
}