#include<stdio.h>
int main()
{
    int a[20],i,n,k,j,h=0,sum=0;
    printf("Enter the n value:");
    scanf("%d",&n);
    printf("Enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter the k value:");
    scanf("%d",&k);
    if(n<0)
    {
        printf("invalid main array size");
    }
    else if(k>n)
    {
        printf("invalid sub array size");
    }
    else
    {
    for(i=0;i<n;i++)
    {
        sum=0;
        for(j=1;j<=k;j++)
        {
            sum=sum+a[i];
            i++;
        }
        i=i-k;
        if(sum>h)
        {
            h=sum;
        }
    }
    printf("%d ",h);
    }
    
}