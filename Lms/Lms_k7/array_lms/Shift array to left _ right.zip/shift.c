#include<stdio.h>
int main()
{
    int n,i,a[10],ri,le,j=1,k=1;
    char choice,r,l;
    scanf("%d",&n);
    if(n<=0)
    {
        printf("No of elements are invalid");
    }
    else
    {
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
        
    }
    scanf(" %c",&choice);
    if(choice=='r')
    {
        scanf("%d",&ri);
        while(j<=ri)
        {
         for(i=n-1;i>0;i--)
         {
            a[i]=a[i-1];
         }
         a[i]=0;
         j++;
        }
        for(i=0;i<n;i++)
        {
            printf("%d ",a[i]);
        }
        
    }
    if(choice=='l')
    {
        scanf("%d",&le);
        while(k<=le)
        {
            for(i=0;i<n-1;i++)
            {
                a[i]=a[i+1];
            }
            a[i]=0;
            k++;
        }
        for(i=0;i<n;i++)
        {
            printf("%d ",a[i]);
        }
    
    }

    }
}