#include<stdio.h>
void check_element(int *,int);
int main()
{
    int n,i,a[50];
    printf("Enter the n value:");
    scanf("%d",&n);
    printf("Enter the elements:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    if(n<=0)
    {
        printf("invalid size");
        
    }
    
    else if(n>50)
    {
        printf("Memory Overflow");
    }
    else if(n>0 &&n<50)
    {
      check_element(a,n);
    }
    
}
void check_element(int *x,int num)
{
        int j,k,count1;
        for(j=0;j<num;j++)
        {
            count1=0;
            for(k=0;k<num;k++)
            {
                if(x[j]==x[k])
                {
                    count1++;
                }
            }
            if(count1==1)
            {
                printf("%d ",x[j]);
            }
        }
        if(count1==num)
        {
            printf("no non-repeated elements");
        }
    
}