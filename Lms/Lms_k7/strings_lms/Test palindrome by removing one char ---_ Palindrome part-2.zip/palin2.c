#include<stdio.h>
#include<string.h>
int main()
{
    int i,j=0,c=0,l=0,k;
    char a[20],t[10],m[20];
    scanf("%[^\n]s",a);
    for(i=strlen(a)-1;i>=0;i--)
    {
        m[l]=a[i];
        l++;
    }
    m[l]='\0';
    if(strcmp(a,m)==0)
    {
        printf("already a palindrome");
    }
    else
    {
    for(i=0;a[i]!='\0';i++)
    {
        t[j]=a[i];
        memmove(a+i,a+i+ 1,strlen(a+i+ 1)+ 1);
        l=0;
        for(k=strlen(a)-1;k>=0;k--)
        {
          m[l]=a[k];
          l++;
        }
        m[l]='\0';
        if(strcmp(a,m)==0)
        {
            c++;
            if(c==1)
            printf("%d ",i);
        }
        else
        {
          memmove(a+i+ 1,a+i,strlen(a+i)+ 1);
          strncpy(a+i,t,1);
        }
    }
    if(c==0)
    {
        printf("can not be a palindrome");
    }
    }
}
