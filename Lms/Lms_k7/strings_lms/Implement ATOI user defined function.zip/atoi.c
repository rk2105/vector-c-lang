#include<stdio.h>
#include<string.h>
int main()
{
    int i,count=0,count1=0,n=0;
    char str[30];
    scanf("%[^\n]s",str);
    for(i=0;str[i];i++)
    {
        count++;
    }
    for(i=0;str[i];i++)
    {
        if((str[0]=='-')||((str[i]>='0')&&(str[i]<='9')))         
        {
            count1++;
        }
    }
    if(count!=count1)
    {
        printf("invalid");
    }
    else
    {
           for(i=0;str[i]!='\0';i++)
           {
              if(str[i]=='-')
              {
                continue;
              }
              n=n*10+str[i]-48;
           }
    
    if(str[0]=='-')
    {
        printf("%d",-n);
        
    }
    else
    {
        printf("%d",n);
    }
    }
    
        
    
}