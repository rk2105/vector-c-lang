#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
char *rev(char *,char*);
int main()
{
    int c=0;
    char str[30],sub[10];
    scanf("%[^\n]s",str);
    __fpurge(stdin);
    scanf("%[^\n]s",sub);
    char *p,*l;
    p=str;
    while(p=strstr(p,sub))
    {
        c++;
        l=rev(p,sub);
        strncpy(p,l,strlen(sub));
        p++;
    }
    if(c==0)
    {
        printf("sub string not found");
    }
    else if(c>1)
    {
        puts(str);
    }
}
char *rev(char *ptr,char *s)
{
    static char temp[10];
    int i,j=0;
    int len=strlen(s);
    for(i=len-1;i>=0;i--)
    {
        temp[j]=s[i];
        j++;
    }
    temp[j]='\0';
    return temp;
}