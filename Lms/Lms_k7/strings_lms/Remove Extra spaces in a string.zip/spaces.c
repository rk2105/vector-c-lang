#include<stdio.h>
#include<string.h>
int main()
{
    int i,c=0,c1=0,f=0;
    char str[50];
    scanf("%[^\n]s",str);
    for(i=0;str[i];i++)
    {
        if(str[i]!=32)
        {
            c1++;
        }
    }
    if(c1==0)
    {
        printf("empty string");
    }
    else
    {
    for(i=0;str[i]!='\0';i++)
    {
       if(str[i]==32)
        {
            c++;
            if(c>1)
            {
                memmove(str+i,str+i+1,strlen(str+i+1)+1);
                f=1;
            }
        }
        else if(str[i]!=32)
        {
            c=0;
        } 
        
    }
    if(str[0]==32)
    {
        memmove(str,str+1,strlen(str+1)+1);
    }
    if(f==0)
    printf("no extra spaces");
    if(f==1)
    puts(str);
    }
    
}
