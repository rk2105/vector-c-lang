#include<stdio.h>
#include<string.h>
int main()
{
    char str[20];
    int c=0,c1=0,c2=0,i;
    scanf("%[^\n]s",str);
    for(i=0;str[i]!='\0';i++)
    {
        c++;
        if(str[i]>=65 && str[i]<=90)
        {
            c1++;
            str[i]=str[i]+32;
        }
        else if(str[i]>=97 && str[i]<=122)
        {
            c1++;
            str[i]=str[i]-32;
        } 
        else if(str[i]>=48 && str[i]<=57 || str[i]==46)
        {
            c2++;
        }
    }
    if(c!=0 && c1==0 && c2==0)
    {
        printf("ERROR");
        
    }
    else if(c!=0 && c1!=0)
    {
         puts(str);
    }
    else if(c2==strlen(str))
    {
        puts(str);
    }
}