#include<stdio.h>
#include<string.h>
void replace(char *,int );
int main()
{
    int c,i,c1=0;
    char s[50],d[]=" ";
    char *t,*p;
    scanf("%[^\n]s",s);
    int len=strlen(s);
    p=s;
    for(i=0;s[i];i++)
    {
        if(s[i]!=32)
        {
            c1++;
        }
    }
    t=strtok(p,d);
    if(s!=d){
         c=0;
    while(t!=NULL)
    {
        char *pi=t+(strlen(t)-1);
        if((*t=='a'||*t=='e'||*t=='i'||*t=='o'||*t=='u')&&(*pi=='a'||*pi=='e'||*pi=='i'||*pi=='o'||*pi=='u') ||((*t=='A')||(*t=='E')||(*t=='I')||(*t=='O')||(*t=='U') &&(*pi=='A')||(*pi=='E')||(*pi=='I')||(*pi=='O')||(*pi=='U')))
        {
            c++;
            printf("%s ",t);
        }
        t=strtok(NULL,d);
    }
    if(c==0 && c1!=0)
    {
        printf("there is no words to print");
    }
    replace(s,len);
    }
     if(c1==0 && c==0)
    {
        printf("empty string");
    }
}

void replace(char *str,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(str[i]=='\0')
        {
            str[i]=32;
        }
    }
}