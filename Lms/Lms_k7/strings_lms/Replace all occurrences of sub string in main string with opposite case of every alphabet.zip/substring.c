#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
int main()
{
    int i,c=0;
    char str[40],sub[20];
    char *p=NULL;
    scanf("%[^\n]s",str);
    __fpurge(stdin);
    scanf("%[^\n]s",sub);
    p=str;
    while(p=strstr(str,sub))
    {
        c++;
        for(i=0;i<strlen(sub);i++)
        {
            if(p[i]>=97 && p[i]<=122)
            {
                p[i]-=32;
            }
            else if(p[i]>=65 &&p[i]<=90)
            {
                p[i]+=32;
            }
        }
        p++;
    }
    if(c>0)
    {
    puts(str);
    }
    if(c==0)
    {
        printf("sub string not found");
    }
        
}