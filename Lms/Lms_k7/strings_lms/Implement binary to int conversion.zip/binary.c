#include<stdio.h>
#include<string.h>
int main()
{
    int i,j,sum=0,p=1,count=0,count1=0;
    char str[20];
    scanf("%[^\n]s",str);
    for(i=0;str[i]!='\0';i++)
    {
        count++;
        
    }
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]=='1'||str[i]=='0')
        {
            count1++;
        }
    }
    if(count!=count1)
    {
        printf("invalid input");
    }
    else
    {
        for(i=strlen(str)-1;i>=0;i--)
        {
            j=str[i]-48;
            sum=sum+j*p;
            p=p*2;
        }
    
    printf("%d ",sum);
    }
}