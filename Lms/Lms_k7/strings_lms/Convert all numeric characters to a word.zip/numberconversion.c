#include<stdio.h>
#include<string.h>
int main()
{
    int i,count=0;
    char str[60];
    scanf("%[^\n]s",str);
    char *ptr;
    ptr=str;
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]>='0'&& str[i]<='9')
        {
            count++;
        }
    }
    if(count<1)
    {
        printf("Numeric character not found.");
        return 0;
    }
    else
    {
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]>='0'&&str[i]<='9')
        {
            if(str[i]=='1')
            {
                char p[]="One";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
                
            }
            else if(str[i]=='2')
            {
                char p[]="Two";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='3')
            {
                char p[]="Three";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='4')
            {
                char p[]="Four";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='5')
            {
                char p[]="Five";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='6')
            {
                char p[]="Six";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='7')
            {
                char p[]="Seven";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='8')
            {
                char p[]="Eight";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='9')
            {
                char p[]="Nine";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            else if(str[i]=='0')
            {
                char p[]="Zero";
                memmove(str+i+1+strlen(p)-1,str+i+1,strlen(str+i+1)+1);
                strncpy(str+i,p,strlen(p));
            }
            
    }
    }
    }
    puts(str);
}