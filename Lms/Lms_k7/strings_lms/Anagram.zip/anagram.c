#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
int main()
{
    int i,k,c=0,c1=0;
    char s1[20],s2[20];
    scanf("%[^\n]s",s1);
    __fpurge(stdin);
    scanf("%[^\n]s",s2);
   // fgets(s1,20,stdin);
  //  fgets(s2,20,stdin);
    for(i=0;s1[i]!='\0';i++)
    {
        c++;
    }
    for(k=0;s2[k]!='\0';k++)
    {
        for(int j=0;s1[j]!='\0';j++)
        {
            if(s2[k]==s1[j])
            {
                c1++;
            }
        }
    }
    if(c1==c)
    {
        printf("Anagram strings");
    }
    else
    {
        printf("Not an anagram strings");
    }
}