#include<stdio.h>
#include<string.h>
int main()
{
    char s1[20],s2[20],temp[10];
    int n;
    fgets(s1,20,stdin);
    fgets(s2,20,stdin);
    //gets(s1);
    //gets(s2);
    if(s1[strlen(s1)-1]=='\n')
    {
        s1[strlen(s1)-1]='\0';
    }
    scanf("%d",&n);
    if(n>strlen(s1)||n<0)
    {
        printf("invalid location");
    }
    
    else
    {
        strcpy(temp,s1+n);
        strcpy(s1+n,s2);
        strcpy(s1+n+strlen(s2)-1,temp);
        puts(s1);
    }
}