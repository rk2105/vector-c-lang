#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    char s[20],t[20],a[20],m[20],te[10];
    int i=0,j,d,di,l,p=0,r=0,digit,y,g;
    double num,n,k,dig,f;
    scanf("%lf",&num);
    if(num<0)
    {  
        t[0]='-';
        n=-num;
    }
    else if(num>0)
    {
        n=num;
    }
    else if(num==0.0)
    {
        printf("0.0000");
        return 0;
    }
    j=(int)n;
    f=(float)j;
    k=n-f;
    d=k * 10000 ;
    while(j!=0)
    {
        di=j%10;
        s[i]=di + 48;
        i++;
        j=j/10;
    }
        if(num<0)
        {
            l=1;
            for(i=strlen(s)-1;i>=0;i--)
            {
               t[l]=s[i];
                 l++;
            }
         }
         else if(num>0)
         {
             l=0;
             for(i=strlen(s)-1;i>=0;i--)
             {
                 t[l]=s[i];
                 l++;
             }
         }
    t[l]='.';
    l++;
    t[l]='\0';
    if(d==0)
    {
      for(g=0;g<4;g++)
      {
          te[g]=48;
      }
      strcat(t,te);
      puts(t);
    }
    else
    {
    while(d!=0)
    {
        digit=d%10;
        a[p]=digit + 48;
        p++;
        d=d/10;
    }
    for(y=strlen(a)-1;y>=0;y--)
    {
        m[r]=a[y];
        r++;
    }
    strcat(t,m);
    puts(t);
    }
    
}