#include<stdio.h>
#include<string.h>
int main()
{
    int i=0,rev=0,d,digit,num,n,l;
    char arr[40];
    scanf("%d",&num);
    scanf("%[^\n]s",arr);
    if(num<0)
    {
        n=-num;
        printf("minus ");
    }
    else if(num>0)
        n=num;
    else if(num==0)
        printf("zero");
    while(n!=0)
    {
        digit=n%10;
        arr[i]=digit + 48;
        i++;
        n=n/10;
    }
    arr[i]='\0';
    l=strlen(arr);
    for(i=l-1;i>=0;i--)
    {
        if(arr[i]==48)
            printf("zero ");
        else if(arr[i]==49)
            printf("one ");
        else if(arr[i]==50)
            printf("two ");
        else if(arr[i]==51)
            printf("three ");
        else if(arr[i]==52)
            printf("four ");
        else if(arr[i]==53)
            printf("five ");
        else if(arr[i]==54)
            printf("six ");
        else if(arr[i]==55)
            printf("seven ");
        else if(arr[i]==56)
            printf("eight ");
        else if(arr[i]==57)
            printf("nine ");
    }
}
