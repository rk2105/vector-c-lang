#include<stdio.h>
#include<string.h>
int main()
{
     char str[20],temp[20]; 
     int i=0,j;
     scanf("%[^\n]s",str);
     int len;
     len=strlen(str);
     for(j=len-1;j>=0;j--)
     {
         temp[i]=str[j];
         i++;
     }
     temp[i]='\0';
     if(strcmp(str,temp)==0)
     {
         printf("palindrome");
     }
     else
     {
         printf("not palindrome");
         
     }
}