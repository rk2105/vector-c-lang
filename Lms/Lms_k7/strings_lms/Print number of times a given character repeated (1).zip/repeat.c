 #include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
int main()
{
    int i,count=0,c=0;
    char ch,str[100];
    char *ptr;
    scanf(" %[^\n]s",str);
    __fpurge(stdin);
    scanf("%c",&ch);
   // puts(str);
    ptr=str;
    int n=strlen(str);
    for(i=0;ptr[i]!='\0';i++)
    {
        c++;
       if(ptr[i]==ch)
       {
           count++;
       }
    }

    if(c==n&&count!=0)
    {
        printf("%d",count);
    }
    else if(c==n&&count==0)
    {
    printf("not found");
    }
    
}