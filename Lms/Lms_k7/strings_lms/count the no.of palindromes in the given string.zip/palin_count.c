#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
char *rev(char *);
void length(char *,int);
int main()
{
    char str[30];
    char d[]=" ";
    char *t,*p,*l;
    int c=0,c1=0;
    scanf("%[^\n]s",str);
    __fpurge(stdin);
    int len=strlen(str);
    p=str;
    t=strtok(p,d);
    while(t!=NULL)
    {
        c1++;
        if(*(t+strlen(t)-1)==44)
        {
            *(t+strlen(t)-1)='\0';
        }
        l=rev(t);
        if(strcmp(l,t)==0)
        {
           c++; 
        } 
        p++;
        t=strtok(NULL,d);
    }
    length(str,len);
    if(c>0 &&c1!=0)
    {
    printf("%d ",c);
    }
    else if(c==0 &&c1!=0)
    {
        printf("no palindromes in the given string");
    }
    else if(c==0 &&c1==0)
    {
        printf("empty string");
    }
}
char *rev(char *tok)
{
    static char temp[20];
    int i,j=0;
    int len=strlen(tok);
    for(i=len-1;i>=0;i--)
    {
        if(tok[i]==',')
        {
            continue;
        }
       temp[j]=tok[i];
       j++;
    }
    temp[j]='\0';
    return temp;
}
void length(char *s,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(s[i]=='\0')
        {
            s[i]=32;
        }
    }
}