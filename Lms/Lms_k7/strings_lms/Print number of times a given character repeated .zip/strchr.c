#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>
int main()
{
    int i,c=0;
    char s[50],ch;
    scanf("%[^\n]s",s);
    __fpurge(stdin);
    scanf("%c",&ch);
    char *p;
    p=s;
    for(i=0;s[i];i++)
    {
        if(s[i]==ch)
        c++;
    }
    if(c==0)
    printf("not found");
    if(c>0)
    printf("%d",c);
    
}