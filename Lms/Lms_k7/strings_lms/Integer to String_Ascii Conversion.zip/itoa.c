#include<stdio.h>
#include<string.h>
int main()
{
    int i=0,j,k,n,digit;
    char temp[20],str[20];
    scanf("%d",&n);
    int a=n;
    if(n<0)
    {
        n=-n;
    }
    while(n!=0)
    {
        digit=n%10;
        str[i]=digit+48;
        i++;
        n=n/10;
    }
    str[i]='\0';
    if(a<0)
    {
        temp[0]='-';
        k=1;
        for(j=strlen(str)-1;j>=0;j--)
        {
            temp[k]=str[j];
            k++;
        }
        temp[k]='\0';
    }
        
    else if(a>0)
        {
            k=0;
          for(j=strlen(str)-1;j>=0;j--)
          {
            temp[k]=str[j];
            k++;
          }
        
    temp[k]='\0';
        }
        else
        {
            printf("%c",48);
        }

    puts(temp);
    
    
    
}